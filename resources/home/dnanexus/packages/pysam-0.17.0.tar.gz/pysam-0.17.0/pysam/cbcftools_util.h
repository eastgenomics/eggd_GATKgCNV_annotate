#ifndef CBCFTOOLS_UTIL_H
#define CBCFTOOLS_UTIL_H

int bcftools_main(int argc, char *argv[]);

#endif
