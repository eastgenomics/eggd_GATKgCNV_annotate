// Version information used while compiling samtools, bcftools, and htslib

#define SAMTOOLS_VERSION "1.13 (pysam)"
#define BCFTOOLS_VERSION "1.13 (pysam)"
#define HTS_VERSION_TEXT "1.13 (pysam)"
