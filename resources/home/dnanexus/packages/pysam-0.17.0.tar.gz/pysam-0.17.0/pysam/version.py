# pysam versioning information
__version__ = "0.17.0"

__samtools_version__ = "1.13"
__bcftools_version__ = "1.13"
__htslib_version__ = "1.13"
