#ifndef CSAMTOOLS_UTIL_H
#define CSAMTOOLS_UTIL_H

int samtools_main(int argc, char *argv[]);

#endif
